#!/bin/bash

echo "======================================"
echo "Iniciando Gerador de Nota Fiscal"
echo "======================================"

# Ativar SDKMAN
source "$HOME/.sdkman/bin/sdkman-init.sh"

# Instalar Java 17 se não estiver instalado
if ! sdk list java | grep -q "17.0.10-tem"; then
    echo "Instalando Java 17..."
    sdk install java 17.0.10-tem
fi

# Usar Java 17
echo "Configurando Java 17..."
sdk use java 17.0.10-tem

# Verificar versão do Java
echo "Versão do Java:"
java -version

# Navegar para o diretório do projeto
cd "/Users/virtualmachine/Desktop/Documentos/Projetos /geradornotafiscal"

# Limpar e compilar o projeto
echo ""
echo "======================================"
echo "Compilando o projeto..."
echo "======================================"
./mvnw clean package -DskipTests

# Verificar se a compilação foi bem-sucedida
if [ $? -eq 0 ]; then
    echo ""
    echo "======================================"
    echo "Compilação bem-sucedida!"
    echo "Iniciando aplicação..."
    echo "======================================"
    echo ""
    ./mvnw spring-boot:run
else
    echo ""
    echo "======================================"
    echo "ERRO: Falha na compilação!"
    echo "======================================"
    echo ""
    echo "Por favor, abra o projeto no IntelliJ IDEA:"
    echo "1. Abra o IntelliJ IDEA"
    echo "2. File → Open"
    echo "3. Selecione: /Users/virtualmachine/Desktop/Documentos/Projetos /geradornotafiscal"
    echo "4. Instale o plugin Lombok (Settings → Plugins)"
    echo "5. Habilite Annotation Processing (Settings → Build → Compiler → Annotation Processors)"
    echo "6. Run 'GeradorNotaFiscalApplication'"
    exit 1
fi
