#!/bin/bash

echo "=========================================="
echo "🚀 GERADOR DE NOTA FISCAL"
echo "=========================================="
echo ""

# Cores
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Matar processo na porta 8080
echo "🔍 Verificando porta 8080..."
if lsof -ti:8080 > /dev/null 2>&1; then
    echo -e "${YELLOW}⚠️  Porta 8080 em uso. Liberando...${NC}"
    lsof -ti:8080 | xargs kill -9
    sleep 2
fi

echo -e "${GREEN}✅ Porta 8080 disponível${NC}"
echo ""

# Navegar para o diretório do projeto
cd "/Users/virtualmachine/Desktop/Documentos/Projetos /geradornotafiscal"

echo "=========================================="
echo "📦 Compilando o projeto..."
echo "=========================================="
./mvnw clean compile -DskipTests

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ Compilação bem-sucedida!${NC}"
else
    echo -e "${RED}❌ Erro na compilação!${NC}"
    echo ""
    echo "💡 SOLUÇÃO: Use o IntelliJ IDEA"
    echo "   1. Abra o IntelliJ IDEA"
    echo "   2. File → Open → Selecione o projeto"
    echo "   3. Instale plugin Lombok"
    echo "   4. Habilite Annotation Processing"
    echo "   5. Run 'GeradorNotaFiscalApplication'"
    exit 1
fi

echo ""
echo "=========================================="
echo "🚀 Iniciando aplicação..."
echo "=========================================="
echo ""
echo -e "${YELLOW}⏳ Aguarde... Isso pode levar ~30 segundos${NC}"
echo ""

# Iniciar aplicação em background
./mvnw spring-boot:run > /tmp/spring-boot-log.txt 2>&1 &
APP_PID=$!

# Aguardar aplicação iniciar
sleep 35

# Verificar se está rodando
echo "🔍 Verificando se aplicação iniciou..."
RESPONSE=$(curl -s http://localhost:8080/api/pedido/health)

if [ $? -eq 0 ]; then
    echo ""
    echo -e "${GREEN}=========================================="
    echo "✅ APLICAÇÃO RODANDO COM SUCESSO!"
    echo "==========================================${NC}"
    echo ""
    echo "🌐 URL: http://localhost:8080"
    echo "📊 Health: http://localhost:8080/api/pedido/health"
    echo ""
    echo "📝 Health Check Response:"
    echo "$RESPONSE" | python3 -m json.tool 2>/dev/null || echo "$RESPONSE"
    echo ""
    echo "=========================================="
    echo "🧪 TESTANDO ENDPOINTS"
    echo "=========================================="
    echo ""

    echo "1️⃣  Testando endpoint home..."
    curl -s http://localhost:8080/api/pedido/ | python3 -m json.tool 2>/dev/null
    echo ""
    echo ""

    echo "2️⃣  Testando geração de nota fiscal..."
    curl -s -X POST http://localhost:8080/api/pedido/gerarNotaFiscal \
      -H "Content-Type: application/json" \
      -d '{
        "id_pedido": 123,
        "data": "2026-01-25",
        "valor_total_itens": 1500.00,
        "valor_frete": 50.00,
        "itens": [
          {
            "id_item": "ITEM001",
            "descricao": "Notebook Dell",
            "valor_unitario": 1500.00,
            "quantidade": 1
          }
        ],
        "destinatario": {
          "nome": "João Silva",
          "tipo_pessoa": "FISICA",
          "documentos": [],
          "enderecos": [
            {
              "cep": "01310-100",
              "logradouro": "Av Paulista",
              "numero": "1000",
              "estado": "SP",
              "finalidade": "ENTREGA",
              "regiao": "SUDESTE"
            }
          ]
        }
      }' | python3 -m json.tool 2>/dev/null | head -30

    echo ""
    echo ""
    echo -e "${GREEN}=========================================="
    echo "✅ TESTES CONCLUÍDOS COM SUCESSO!"
    echo "==========================================${NC}"
    echo ""
    echo "📋 PRÓXIMOS PASSOS:"
    echo ""
    echo "   1. Aplicação está RODANDO na porta 8080"
    echo "   2. Veja os logs em: /tmp/spring-boot-log.txt"
    echo "   3. Acesse no navegador: http://localhost:8080/api/pedido/"
    echo "   4. Use Postman para testar: POST /api/pedido/gerarNotaFiscal"
    echo ""
    echo "   Para PARAR a aplicação:"
    echo "   kill $APP_PID"
    echo ""
    echo "   OU"
    echo ""
    echo "   lsof -ti:8080 | xargs kill -9"
    echo ""

    # Manter script rodando
    echo -e "${YELLOW}Pressione CTRL+C para parar a aplicação...${NC}"
    wait $APP_PID

else
    echo ""
    echo -e "${RED}=========================================="
    echo "❌ APLICAÇÃO NÃO INICIOU!"
    echo "==========================================${NC}"
    echo ""
    echo "📋 Veja os logs em: /tmp/spring-boot-log.txt"
    echo ""
    tail -50 /tmp/spring-boot-log.txt
    echo ""
    echo "💡 SOLUÇÃO RECOMENDADA:"
    echo ""
    echo "   Use o IntelliJ IDEA para rodar:"
    echo "   1. Abra o IntelliJ IDEA"
    echo "   2. File → Open → Selecione o projeto"
    echo "   3. Instale plugin Lombok"
    echo "   4. Habilite Annotation Processing"
    echo "   5. Run 'GeradorNotaFiscalApplication'"
    echo ""

    # Matar processo se ainda estiver rodando
    kill $APP_PID 2>/dev/null

    exit 1
fi
