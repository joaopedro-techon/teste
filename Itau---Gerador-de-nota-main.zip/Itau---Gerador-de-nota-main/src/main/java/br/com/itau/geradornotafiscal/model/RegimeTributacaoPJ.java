package br.com.itau.geradornotafiscal.model;

public enum RegimeTributacaoPJ {
    SIMPLES_NACIONAL,
    LUCRO_REAL,
    LUCRO_PRESUMIDO,
    OUTROS
}

