package br.com.itau.geradornotafiscal.web.controller;

import br.com.itau.geradornotafiscal.model.NotaFiscal;
import br.com.itau.geradornotafiscal.model.Pedido;
import br.com.itau.geradornotafiscal.model.TipoPessoa;
import br.com.itau.geradornotafiscal.service.GeradorNotaFiscalService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/pedido")
@Tag(name = "Nota Fiscal", description = "API para geração de notas fiscais")
public class GeradorNFController {

    private static final Logger logger = LoggerFactory.getLogger(GeradorNFController.class);

    @Autowired
    private GeradorNotaFiscalService notaFiscalService;

    @Operation(summary = "Health Check", description = "Verifica se a aplicação está rodando")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Aplicação está rodando",
            content = @Content(schema = @Schema(implementation = Map.class)))
    })
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> health() {
        Map<String, Object> health = new HashMap<>();
        health.put("status", "UP");
        health.put("service", "Gerador de Nota Fiscal");
        health.put("version", "1.0.0");
        health.put("timestamp", System.currentTimeMillis());
        logger.info("Health check executado");
        return ResponseEntity.ok(health);
    }

    @Operation(summary = "Informações da API", description = "Retorna informações sobre a API")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Informações retornadas com sucesso",
            content = @Content(schema = @Schema(implementation = Map.class)))
    })
    @GetMapping("/")
    public ResponseEntity<Map<String, String>> home() {
        Map<String, String> info = new HashMap<>();
        info.put("message", "Bem-vindo ao Gerador de Nota Fiscal API");
        info.put("version", "1.0.0");
        info.put("endpoint", "POST /api/pedido/gerarNotaFiscal");
        info.put("health", "GET /api/pedido/health");
        return ResponseEntity.ok(info);
    }

    @Operation(summary = "Gerar Nota Fiscal",
               description = "Gera uma nota fiscal completa a partir de um pedido, calculando automaticamente os impostos baseados no tipo de pessoa e regime tributário",
               security = @SecurityRequirement(name = "bearerAuth"))
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Nota fiscal gerada com sucesso",
            content = @Content(schema = @Schema(implementation = NotaFiscal.class))),
        @ApiResponse(responseCode = "400", description = "Dados do pedido inválidos",
            content = @Content(schema = @Schema(implementation = String.class))),
        @ApiResponse(responseCode = "401", description = "Não autenticado - Token JWT inválido ou ausente",
            content = @Content(schema = @Schema(implementation = String.class))),
        @ApiResponse(responseCode = "500", description = "Erro interno ao processar pedido",
            content = @Content(schema = @Schema(implementation = String.class)))
    })
    @PostMapping("/gerarNotaFiscal")
    public ResponseEntity<NotaFiscal> gerarNotaFiscal(@Valid @RequestBody Pedido pedido) {
        try {
            logger.info("Recebendo pedido ID: {}", pedido.getIdPedido());

            validarRegimeTributarioPJ(pedido);

            logInformacoesPedido(pedido);

            NotaFiscal notaFiscal = notaFiscalService.gerarNotaFiscal(pedido);

            logger.info("Nota fiscal gerada com sucesso - ID: {}", notaFiscal.getIdNotaFiscal());

            return new ResponseEntity<>(notaFiscal, HttpStatus.OK);

        } catch (Exception e) {
            logger.error("Erro ao gerar nota fiscal para o pedido ID: {}", pedido.getIdPedido(), e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private void validarRegimeTributarioPJ(Pedido pedido) {
        if (pedido.getDestinatario().getTipoPessoa() == TipoPessoa.JURIDICA
            && pedido.getDestinatario().getRegimeTributacao() == null) {
            throw new IllegalArgumentException("Regime tributário é obrigatório para pessoa jurídica");
        }
    }


    private void logInformacoesPedido(Pedido pedido) {
        logger.info("Processando pedido - Valor Total: R$ {}, Frete: R$ {}, Quantidade de itens: {}",
                pedido.getValorTotalItens(),
                pedido.getValorFrete(),
                pedido.getItens().size());


        logger.info("Destinatário: {}, Tipo: {}",
                pedido.getDestinatario().getNome(),
                pedido.getDestinatario().getTipoPessoa());
    }
}
