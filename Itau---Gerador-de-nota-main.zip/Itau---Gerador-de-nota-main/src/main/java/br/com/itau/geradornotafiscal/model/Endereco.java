package br.com.itau.geradornotafiscal.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Endereco {
    @JsonProperty("cep")
    @NotNull(message = "CEP é obrigatório")
    @NotBlank(message = "CEP não pode estar vazio")
    @Pattern(regexp = "\\d{5}-?\\d{3}", message = "CEP deve estar no formato 00000-000")
    private String cep;

    @JsonProperty("logradouro")
    @NotNull(message = "Logradouro é obrigatório")
    @NotBlank(message = "Logradouro não pode estar vazio")
    private String logradouro;

    @JsonProperty("numero")
    @NotNull(message = "Número é obrigatório")
    @NotBlank(message = "Número não pode estar vazio")
    private String numero;

    @JsonProperty("estado")
    @NotNull(message = "Estado é obrigatório")
    @NotBlank(message = "Estado não pode estar vazio")
    @Size(min = 2, max = 2, message = "Estado deve ter 2 caracteres (UF)")
    private String estado;

    @JsonProperty("complemento")
    private String complemento;

    @JsonProperty("finalidade")
    @NotNull(message = "Finalidade do endereço é obrigatória")
    private Finalidade finalidade;

    @JsonProperty("regiao")
    @NotNull(message = "Região é obrigatória")
    private Regiao regiao;
}

