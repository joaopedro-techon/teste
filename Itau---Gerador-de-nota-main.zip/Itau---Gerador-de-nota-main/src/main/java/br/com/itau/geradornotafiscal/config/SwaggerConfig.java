package br.com.itau.geradornotafiscal.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {

    private static final String SECURITY_SCHEME_NAME = "bearerAuth";

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .addSecurityItem(new SecurityRequirement().addList(SECURITY_SCHEME_NAME))
                .components(new Components()
                        .addSecuritySchemes(SECURITY_SCHEME_NAME,
                                new SecurityScheme()
                                        .name(SECURITY_SCHEME_NAME)
                                        .type(SecurityScheme.Type.HTTP)
                                        .scheme("bearer")
                                        .bearerFormat("JWT")
                                        .description("Insira o token JWT no formato: Bearer {token}")))
                .info(new Info()
                        .title("Gerador de Nota Fiscal API")
                        .version("2.1.0")
                        .description("API REST para geração automática de notas fiscais com cálculo de impostos por tipo de pessoa (Física/Jurídica) e regime tributário.\n\n" +
                                "**Autenticação JWT:**\n" +
                                "- Para testar endpoints protegidos, clique no botão 'Authorize' (🔒)\n" +
                                "- Insira o token JWT no formato: `Bearer {seu_token_aqui}`\n" +
                                "- O token será incluído automaticamente em todas as requisições\n\n" +
                                "**Exemplo de token:** Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...")
                        .contact(new Contact()
                                .name("Time Itaú")
                                .email("suporte@itau.com.br")
                                .url("https://www.itau.com.br"))
                        .license(new License()
                                .name("Apache 2.0")
                                .url("https://www.apache.org/licenses/LICENSE-2.0.html")));
    }
}
