package br.com.itau.geradornotafiscal.service.impl;

import br.com.itau.geradornotafiscal.model.NotaFiscal;
import br.com.itau.geradornotafiscal.port.out.EntregaIntegrationPort;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EntregaService {

    private static final Logger logger = LoggerFactory.getLogger(EntregaService.class);
    private static final long TEMPO_PROCESSAMENTO_MS = 150;

    public void agendarEntrega(NotaFiscal notaFiscal) {
        try {
            logger.info("Processando agendamento de entrega para NF {}", notaFiscal.getIdNotaFiscal());
            Thread.sleep(TEMPO_PROCESSAMENTO_MS);
            new EntregaIntegrationPort().criarAgendamentoEntrega(notaFiscal);
        } catch (InterruptedException e) {
            logger.error("Erro ao agendar entrega", e);
            Thread.currentThread().interrupt();
            throw new RuntimeException("Falha ao agendar entrega", e);
        }
    }
}
