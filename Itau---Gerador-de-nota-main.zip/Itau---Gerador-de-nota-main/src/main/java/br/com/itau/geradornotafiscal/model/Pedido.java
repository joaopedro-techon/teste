package br.com.itau.geradornotafiscal.model;

import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import javax.validation.Valid;
import javax.validation.constraints.*;

@Builder
@AllArgsConstructor
@Getter
@Setter
@NoArgsConstructor
public class Pedido {
    @JsonProperty("id_pedido")
    @NotNull(message = "ID do pedido é obrigatório")
    @Min(value = 1, message = "ID do pedido deve ser maior que zero")
    private int idPedido;

    @JsonProperty("data")
    @NotNull(message = "Data do pedido é obrigatória")
    private LocalDate data;

    @JsonProperty("valor_total_itens")
    @NotNull(message = "Valor total dos itens é obrigatório")
    @DecimalMin(value = "0.0", message = "Valor total não pode ser negativo")
    private double valorTotalItens;

    @JsonProperty("valor_frete")
    @NotNull(message = "Valor do frete é obrigatório")
    @DecimalMin(value = "0.0", message = "Valor do frete não pode ser negativo")
    private double valorFrete;

    @JsonProperty("itens")
    @NotNull(message = "Lista de itens é obrigatória")
    @NotEmpty(message = "Pedido deve ter pelo menos um item")
    @Size(min = 1, message = "Pedido deve ter pelo menos um item")
    @Valid
    private List<Item> itens;

    @JsonProperty("destinatario")
    @NotNull(message = "Destinatário é obrigatório")
    @Valid
    private Destinatario destinatario;
}
