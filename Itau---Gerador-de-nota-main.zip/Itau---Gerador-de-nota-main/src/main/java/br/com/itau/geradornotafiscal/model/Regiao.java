package br.com.itau.geradornotafiscal.model;


public enum Regiao {
    NORTE,
    NORDESTE,
    CENTRO_OESTE,
    SUDESTE,
    SUL
}
