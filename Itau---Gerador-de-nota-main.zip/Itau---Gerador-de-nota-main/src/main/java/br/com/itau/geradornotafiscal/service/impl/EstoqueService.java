package br.com.itau.geradornotafiscal.service.impl;

import br.com.itau.geradornotafiscal.model.NotaFiscal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EstoqueService {

    private static final Logger logger = LoggerFactory.getLogger(EstoqueService.class);
    private static final long TEMPO_PROCESSAMENTO_MS = 380;

    public void enviarNotaFiscalParaBaixaEstoque(NotaFiscal notaFiscal) {
        try {
            logger.info("Enviando NF {} para baixa de estoque - {} itens",
                notaFiscal.getIdNotaFiscal(),
                notaFiscal.getItens().size());
            Thread.sleep(TEMPO_PROCESSAMENTO_MS);
            logger.info("✓ Estoque atualizado com sucesso");
        } catch (InterruptedException e) {
            logger.error("Erro ao processar baixa de estoque", e);
            Thread.currentThread().interrupt();
            throw new RuntimeException("Falha ao processar baixa de estoque", e);
        }
    }
}
