package br.com.itau.geradornotafiscal.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.*;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class Item {
	 @JsonProperty("id_item")
	 @NotNull(message = "ID do item é obrigatório")
	 @NotBlank(message = "ID do item não pode estar vazio")
	    private String idItem;

	    @JsonProperty("descricao")
	    @NotNull(message = "Descrição do item é obrigatória")
	    @NotBlank(message = "Descrição não pode estar vazia")
	    @Size(min = 3, max = 200, message = "Descrição deve ter entre 3 e 200 caracteres")
	    private String descricao;

	    @JsonProperty("valor_unitario")
	    @NotNull(message = "Valor unitário é obrigatório")
	    @DecimalMin(value = "0.01", message = "Valor unitário deve ser maior que zero")
	    private double valorUnitario;

	    @JsonProperty("quantidade")
	    @NotNull(message = "Quantidade é obrigatória")
	    @Min(value = 1, message = "Quantidade deve ser maior que zero")
	    private int quantidade;
}

