package br.com.itau.geradornotafiscal.service.impl;

import br.com.itau.geradornotafiscal.model.NotaFiscal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RegistroService {

    private static final Logger logger = LoggerFactory.getLogger(RegistroService.class);
    private static final long TEMPO_PROCESSAMENTO_MS = 500;

    public void registrarNotaFiscal(NotaFiscal notaFiscal) {
        try {
            logger.info("Registrando nota fiscal {} no sistema", notaFiscal.getIdNotaFiscal());
            Thread.sleep(TEMPO_PROCESSAMENTO_MS);
            logger.info("✓ Nota fiscal registrada com sucesso");
        } catch (InterruptedException e) {
            logger.error("Erro ao registrar nota fiscal", e);
            Thread.currentThread().interrupt();
            throw new RuntimeException("Falha ao registrar nota fiscal", e);
        }
    }
}
