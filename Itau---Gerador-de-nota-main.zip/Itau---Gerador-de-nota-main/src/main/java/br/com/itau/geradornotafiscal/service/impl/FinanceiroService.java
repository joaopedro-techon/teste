package br.com.itau.geradornotafiscal.service.impl;

import br.com.itau.geradornotafiscal.model.NotaFiscal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FinanceiroService {

    private static final Logger logger = LoggerFactory.getLogger(FinanceiroService.class);
    private static final long TEMPO_PROCESSAMENTO_MS = 250;

    public void enviarNotaFiscalParaContasReceber(NotaFiscal notaFiscal) {
        try {
            logger.info("Enviando NF {} para contas a receber - Valor total: R$ {}",
                notaFiscal.getIdNotaFiscal(),
                notaFiscal.getValorTotalItens() + notaFiscal.getValorFrete());
            Thread.sleep(TEMPO_PROCESSAMENTO_MS);
            logger.info("✓ NF enviada para contas a receber");
        } catch (InterruptedException e) {
            logger.error("Erro ao enviar para contas a receber", e);
            Thread.currentThread().interrupt();
            throw new RuntimeException("Falha ao enviar para contas a receber", e);
        }
    }
}
