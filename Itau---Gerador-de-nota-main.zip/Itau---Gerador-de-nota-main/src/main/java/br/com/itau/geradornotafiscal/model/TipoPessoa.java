package br.com.itau.geradornotafiscal.model;

public enum TipoPessoa {
    FISICA,
    JURIDICA
}


