package br.com.itau.geradornotafiscal.model;

public enum TipoDocumento {
    CPF,
    CNPJ
}