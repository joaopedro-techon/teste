package br.com.itau.geradornotafiscal.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import javax.validation.Valid;
import javax.validation.constraints.*;

@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Destinatario {
	@JsonProperty("nome")
	@NotNull(message = "Nome do destinatário é obrigatório")
	@NotBlank(message = "Nome não pode estar vazio")
	@Size(min = 3, max = 100, message = "Nome deve ter entre 3 e 100 caracteres")
	private String nome;

	@JsonProperty("tipo_pessoa")
	@NotNull(message = "Tipo de pessoa é obrigatório")
	private TipoPessoa tipoPessoa;

	@JsonProperty("regime_tributacao")
	private RegimeTributacaoPJ regimeTributacao;

	@JsonProperty("documentos")
	private List<Documento> documentos;

	@JsonProperty("enderecos")
	@NotNull(message = "Lista de endereços é obrigatória")
	@NotEmpty(message = "Destinatário deve ter pelo menos um endereço")
	@Valid
	private List<Endereco> enderecos;
}


