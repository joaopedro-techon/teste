package br.com.itau.geradornotafiscal.service.impl;

import br.com.itau.geradornotafiscal.model.*;
import br.com.itau.geradornotafiscal.service.CalculadoraAliquotaProduto;
import br.com.itau.geradornotafiscal.service.GeradorNotaFiscalService;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class GeradorNotaFiscalServiceImpl implements GeradorNotaFiscalService {

    private static final double FATOR_FRETE_NORTE = 1.08;
    private static final double FATOR_FRETE_NORDESTE = 1.085;
    private static final double FATOR_FRETE_CENTRO_OESTE = 1.07;
    private static final double FATOR_FRETE_SUDESTE = 1.048;
    private static final double FATOR_FRETE_SUL = 1.06;

    @Override
    public NotaFiscal gerarNotaFiscal(Pedido pedido) {
        Destinatario destinatario = pedido.getDestinatario();
        TipoPessoa tipoPessoa = destinatario.getTipoPessoa();

        List<ItemNotaFiscal> itensNotaFiscal = calcularItensComTributos(pedido, destinatario, tipoPessoa);
        double valorFreteComTributo = calcularFreteComTributo(pedido, destinatario);

        NotaFiscal notaFiscal = construirNotaFiscal(pedido, itensNotaFiscal, valorFreteComTributo);

        processarIntegracoes(notaFiscal);

        return notaFiscal;
    }

    private List<ItemNotaFiscal> calcularItensComTributos(Pedido pedido, Destinatario destinatario, TipoPessoa tipoPessoa) {
        CalculadoraAliquotaProduto calculadora = new CalculadoraAliquotaProduto();
        double aliquota = calcularAliquota(pedido.getValorTotalItens(), tipoPessoa, destinatario.getRegimeTributacao());
        return calculadora.calcularAliquota(pedido.getItens(), aliquota);
    }

    private double calcularAliquota(double valorTotal, TipoPessoa tipoPessoa, RegimeTributacaoPJ regimeTributacao) {
        if (tipoPessoa == TipoPessoa.FISICA) {
            return calcularAliquotaPessoaFisica(valorTotal);
        } else {
            return calcularAliquotaPessoaJuridica(valorTotal, regimeTributacao);
        }
    }

    private double calcularAliquotaPessoaFisica(double valorTotal) {
        if (valorTotal < 500) return 0;
        if (valorTotal <= 2000) return 0.12;
        if (valorTotal <= 3500) return 0.15;
        return 0.17;
    }

    private double calcularAliquotaPessoaJuridica(double valorTotal, RegimeTributacaoPJ regime) {
        if (regime == RegimeTributacaoPJ.SIMPLES_NACIONAL) {
            return calcularAliquotaSimplesNacional(valorTotal);
        } else if (regime == RegimeTributacaoPJ.LUCRO_REAL) {
            return calcularAliquotaLucroReal(valorTotal);
        } else if (regime == RegimeTributacaoPJ.LUCRO_PRESUMIDO) {
            return calcularAliquotaLucroPresumido(valorTotal);
        }
        return 0;
    }

    private double calcularAliquotaSimplesNacional(double valorTotal) {
        if (valorTotal < 1000) return 0.03;
        if (valorTotal <= 2000) return 0.07;
        if (valorTotal <= 5000) return 0.13;
        return 0.19;
    }

    private double calcularAliquotaLucroReal(double valorTotal) {
        if (valorTotal < 1000) return 0.03;
        if (valorTotal <= 2000) return 0.09;
        if (valorTotal <= 5000) return 0.15;
        return 0.20;
    }

    private double calcularAliquotaLucroPresumido(double valorTotal) {
        if (valorTotal < 1000) return 0.03;
        if (valorTotal <= 2000) return 0.09;
        if (valorTotal <= 5000) return 0.16;
        return 0.20;
    }

    private double calcularFreteComTributo(Pedido pedido, Destinatario destinatario) {
        Regiao regiao = destinatario.getEnderecos().stream()
                .filter(endereco -> endereco.getFinalidade() == Finalidade.ENTREGA ||
                                   endereco.getFinalidade() == Finalidade.COBRANCA_ENTREGA)
                .map(Endereco::getRegiao)
                .findFirst()
                .orElse(null);

        double fatorFrete = obterFatorFretePorRegiao(regiao);
        return pedido.getValorFrete() * fatorFrete;
    }

    private double obterFatorFretePorRegiao(Regiao regiao) {
        if (regiao == null) return 1.0;

        return switch (regiao) {
            case NORTE -> FATOR_FRETE_NORTE;
            case NORDESTE -> FATOR_FRETE_NORDESTE;
            case CENTRO_OESTE -> FATOR_FRETE_CENTRO_OESTE;
            case SUDESTE -> FATOR_FRETE_SUDESTE;
            case SUL -> FATOR_FRETE_SUL;
        };
    }

    private NotaFiscal construirNotaFiscal(Pedido pedido, List<ItemNotaFiscal> itens, double valorFrete) {
        return NotaFiscal.builder()
                .idNotaFiscal(UUID.randomUUID().toString())
                .data(LocalDateTime.now())
                .valorTotalItens(pedido.getValorTotalItens())
                .valorFrete(valorFrete)
                .itens(itens)
                .destinatario(pedido.getDestinatario())
                .build();
    }

    private void processarIntegracoes(NotaFiscal notaFiscal) {
        new EstoqueService().enviarNotaFiscalParaBaixaEstoque(notaFiscal);
        new RegistroService().registrarNotaFiscal(notaFiscal);
        new EntregaService().agendarEntrega(notaFiscal);
        new FinanceiroService().enviarNotaFiscalParaContasReceber(notaFiscal);
    }
}

