package br.com.itau.geradornotafiscal.model;

public enum Finalidade {
    COBRANCA_ENTREGA,
    ENTREGA,
    COBRANCA,
    OUTROS
}