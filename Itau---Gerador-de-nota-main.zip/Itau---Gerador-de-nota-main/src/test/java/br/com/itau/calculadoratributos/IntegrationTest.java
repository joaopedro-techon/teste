package br.com.itau.calculadoratributos;

import br.com.itau.geradornotafiscal.GeradorNotaFiscalApplication;
import br.com.itau.geradornotafiscal.model.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.time.LocalDate;
import java.util.Collections;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.hamcrest.Matchers.*;

@SpringBootTest(classes = GeradorNotaFiscalApplication.class)
@AutoConfigureMockMvc
@DisplayName("Testes de Integração - Controller")
public class IntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    @DisplayName("Deve gerar nota fiscal com sucesso para Pessoa Física")
    public void deveGerarNotaFiscalPessoaFisica() throws Exception {
        Pedido pedido = criarPedidoBase(1500, 50, TipoPessoa.FISICA, null, Regiao.SUDESTE);

        mockMvc.perform(post("/api/pedido/gerarNotaFiscal")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(pedido)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.idNotaFiscal").exists())
                .andExpect(jsonPath("$.valorTotalItens").value(1500.0))
                .andExpect(jsonPath("$.valorFrete").value(greaterThan(50.0)))
                .andExpect(jsonPath("$.itens").isArray())
                .andExpect(jsonPath("$.itens[0].valorTributoItem").exists());
    }

    @Test
    @DisplayName("Deve gerar nota fiscal com sucesso para Pessoa Jurídica")
    public void deveGerarNotaFiscalPessoaJuridica() throws Exception {
        Pedido pedido = criarPedidoBase(3000, 100, TipoPessoa.JURIDICA,
            RegimeTributacaoPJ.SIMPLES_NACIONAL, Regiao.SUL);

        mockMvc.perform(post("/api/pedido/gerarNotaFiscal")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(pedido)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.idNotaFiscal").exists())
                .andExpect(jsonPath("$.valorTotalItens").value(3000.0))
                .andExpect(jsonPath("$.itens[0].valorTributoItem").value(greaterThan(0.0)));
    }

    @Test
    @DisplayName("Deve retornar 400 quando pedido não tem ID")
    public void deveRetornar400QuandoPedidoSemId() throws Exception {
        Pedido pedido = criarPedidoBase(1000, 50, TipoPessoa.FISICA, null, Regiao.SUDESTE);
        pedido.setIdPedido(0);

        mockMvc.perform(post("/api/pedido/gerarNotaFiscal")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(pedido)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("Deve retornar 400 quando pedido não tem itens")
    public void deveRetornar400QuandoPedidoSemItens() throws Exception {
        Pedido pedido = criarPedidoBase(1000, 50, TipoPessoa.FISICA, null, Regiao.SUDESTE);
        pedido.setItens(Collections.emptyList());

        mockMvc.perform(post("/api/pedido/gerarNotaFiscal")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(pedido)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("Deve retornar 400 quando pedido não tem destinatário")
    public void deveRetornar400QuandoPedidoSemDestinatario() throws Exception {
        Pedido pedido = criarPedidoBase(1000, 50, TipoPessoa.FISICA, null, Regiao.SUDESTE);
        pedido.setDestinatario(null);

        mockMvc.perform(post("/api/pedido/gerarNotaFiscal")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(pedido)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("Deve processar pedido com múltiplos itens")
    public void deveProcessarPedidoComMultiplosItens() throws Exception {
        Pedido pedido = criarPedidoBase(2000, 50, TipoPessoa.FISICA, null, Regiao.SUDESTE);

        Item item2 = new Item();
        item2.setIdItem("ITEM002");
        item2.setDescricao("Produto 2");
        item2.setValorUnitario(100);
        item2.setQuantidade(5);

        pedido.getItens().add(item2);

        mockMvc.perform(post("/api/pedido/gerarNotaFiscal")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(pedido)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.itens").isArray())
                .andExpect(jsonPath("$.itens", hasSize(2)));
    }

    @Test
    @DisplayName("Deve aplicar acréscimo de frete correto para cada região")
    public void deveAplicarAcrescimoFretePorRegiao() throws Exception {
        Pedido pedido = criarPedidoBase(1000, 100, TipoPessoa.FISICA, null, Regiao.NORTE);

        MvcResult result = mockMvc.perform(post("/api/pedido/gerarNotaFiscal")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(pedido)))
                .andExpect(status().isOk())
                .andReturn();

        String responseBody = result.getResponse().getContentAsString();
        NotaFiscal notaFiscal = objectMapper.readValue(responseBody, NotaFiscal.class);

        // Norte deve ter 8% de acréscimo
        assert notaFiscal.getValorFrete() == 108.0;
    }

    @Test
    @DisplayName("Deve calcular tributo corretamente para diferentes regimes")
    public void deveCalcularTributoParaDiferentesRegimes() throws Exception {
        // Teste Simples Nacional
        Pedido pedidoSimples = criarPedidoBase(3000, 50, TipoPessoa.JURIDICA,
            RegimeTributacaoPJ.SIMPLES_NACIONAL, Regiao.SUDESTE);

        mockMvc.perform(post("/api/pedido/gerarNotaFiscal")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(pedidoSimples)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.itens[0].valorTributoItem").value(0.13 * 300));

        // Teste Lucro Real
        Pedido pedidoReal = criarPedidoBase(3000, 50, TipoPessoa.JURIDICA,
            RegimeTributacaoPJ.LUCRO_REAL, Regiao.SUDESTE);

        mockMvc.perform(post("/api/pedido/gerarNotaFiscal")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(pedidoReal)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.itens[0].valorTributoItem").value(0.15 * 300));
    }

    private Pedido criarPedidoBase(double valorTotal, double valorFrete, TipoPessoa tipoPessoa,
                                   RegimeTributacaoPJ regime, Regiao regiao) {
        Pedido pedido = new Pedido();
        pedido.setIdPedido(123);
        pedido.setData(LocalDate.now());
        pedido.setValorTotalItens(valorTotal);
        pedido.setValorFrete(valorFrete);

        Destinatario destinatario = new Destinatario();
        destinatario.setNome("Cliente Teste");
        destinatario.setTipoPessoa(tipoPessoa);

        if (regime != null) {
            destinatario.setRegimeTributacao(regime);
        }

        Endereco endereco = new Endereco();
        endereco.setCep("01310-100");
        endereco.setLogradouro("Av Paulista");
        endereco.setNumero("1000");
        endereco.setEstado("SP");
        endereco.setFinalidade(Finalidade.ENTREGA);
        endereco.setRegiao(regiao);

        destinatario.setEnderecos(Collections.singletonList(endereco));
        pedido.setDestinatario(destinatario);

        Item item = new Item();
        item.setIdItem("ITEM001");
        item.setDescricao("Produto Teste");
        item.setValorUnitario(valorTotal / 10);
        item.setQuantidade(10);

        pedido.setItens(Collections.singletonList(item));

        return pedido;
    }
}
