package br.com.itau.calculadoratributos;

import br.com.itau.geradornotafiscal.model.*;
import br.com.itau.geradornotafiscal.service.impl.GeradorNotaFiscalServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Nested;

import java.time.LocalDate;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Gerador de Nota Fiscal - Testes")
public class GeradorNotaFiscalServiceImplTest {

    private GeradorNotaFiscalServiceImpl geradorNotaFiscalService;

    @BeforeEach
    public void setup() {
        geradorNotaFiscalService = new GeradorNotaFiscalServiceImpl();
    }

    @Nested
    @DisplayName("Testes para Pessoa Física")
    class PessoaFisicaTests {

        @Test
        @DisplayName("Deve calcular alíquota 0% para valor < R$ 500")
        public void deveCalcularAliquotaZeroParaValorMenorQue500() {
            Pedido pedido = criarPedidoBase(400, 100, TipoPessoa.FISICA, null, Regiao.SUDESTE);

            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);

            assertNotNull(notaFiscal);
            assertNotNull(notaFiscal.getIdNotaFiscal());
            assertEquals(400, notaFiscal.getValorTotalItens());
            assertEquals(1, notaFiscal.getItens().size());
            assertEquals(0, notaFiscal.getItens().get(0).getValorTributoItem(), 0.01);
            assertTrue(notaFiscal.getValorFrete() > 100);
        }

        @Test
        @DisplayName("Deve calcular alíquota 12% para valor entre R$ 500 e R$ 2.000")
        public void deveCalcularAliquota12ParaValorEntre500E2000() {
            Pedido pedido = criarPedidoBase(1500, 50, TipoPessoa.FISICA, null, Regiao.SUL);

            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);

            assertNotNull(notaFiscal);
            assertEquals(1500, notaFiscal.getValorTotalItens());
            assertEquals(1, notaFiscal.getItens().size());
            assertEquals(0.12 * 150, notaFiscal.getItens().get(0).getValorTributoItem(), 0.01);
        }

        @Test
        @DisplayName("Deve calcular alíquota 15% para valor entre R$ 2.000 e R$ 3.500")
        public void deveCalcularAliquota15ParaValorEntre2000E3500() {
            Pedido pedido = criarPedidoBase(3000, 75, TipoPessoa.FISICA, null, Regiao.NORDESTE);

            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);

            assertNotNull(notaFiscal);
            assertEquals(3000, notaFiscal.getValorTotalItens());
            assertEquals(0.15 * 300, notaFiscal.getItens().get(0).getValorTributoItem(), 0.01);
        }

        @Test
        @DisplayName("Deve calcular alíquota 17% para valor > R$ 3.500")
        public void deveCalcularAliquota17ParaValorMaiorQue3500() {
            Pedido pedido = criarPedidoBase(5000, 100, TipoPessoa.FISICA, null, Regiao.NORTE);

            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);

            assertNotNull(notaFiscal);
            assertEquals(5000, notaFiscal.getValorTotalItens());
            assertEquals(0.17 * 500, notaFiscal.getItens().get(0).getValorTributoItem(), 0.01);
        }
    }

    @Nested
    @DisplayName("Testes para Pessoa Jurídica - Simples Nacional")
    class PessoaJuridicaSimplesNacionalTests {

        @Test
        @DisplayName("Deve calcular alíquota 3% para valor < R$ 1.000")
        public void deveCalcularAliquota3ParaValorMenorQue1000() {
            Pedido pedido = criarPedidoBase(800, 50, TipoPessoa.JURIDICA,
                RegimeTributacaoPJ.SIMPLES_NACIONAL, Regiao.SUDESTE);

            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);

            assertNotNull(notaFiscal);
            assertEquals(800, notaFiscal.getValorTotalItens());
            assertEquals(0.03 * 80, notaFiscal.getItens().get(0).getValorTributoItem(), 0.01);
        }

        @Test
        @DisplayName("Deve calcular alíquota 7% para valor entre R$ 1.000 e R$ 2.000")
        public void deveCalcularAliquota7ParaValorEntre1000E2000() {
            Pedido pedido = criarPedidoBase(1500, 50, TipoPessoa.JURIDICA,
                RegimeTributacaoPJ.SIMPLES_NACIONAL, Regiao.SUL);

            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);

            assertEquals(0.07 * 150, notaFiscal.getItens().get(0).getValorTributoItem(), 0.01);
        }

        @Test
        @DisplayName("Deve calcular alíquota 13% para valor entre R$ 2.000 e R$ 5.000")
        public void deveCalcularAliquota13ParaValorEntre2000E5000() {
            Pedido pedido = criarPedidoBase(3500, 75, TipoPessoa.JURIDICA,
                RegimeTributacaoPJ.SIMPLES_NACIONAL, Regiao.CENTRO_OESTE);

            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);

            assertEquals(0.13 * 350, notaFiscal.getItens().get(0).getValorTributoItem(), 0.01);
        }

        @Test
        @DisplayName("Deve calcular alíquota 19% para valor > R$ 5.000")
        public void deveCalcularAliquota19ParaValorMaiorQue5000() {
            Pedido pedido = criarPedidoBase(6000, 100, TipoPessoa.JURIDICA,
                RegimeTributacaoPJ.SIMPLES_NACIONAL, Regiao.NORDESTE);

            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);

            assertEquals(0.19 * 600, notaFiscal.getItens().get(0).getValorTributoItem(), 0.01);
        }
    }

    @Nested
    @DisplayName("Testes para Pessoa Jurídica - Lucro Real")
    class PessoaJuridicaLucroRealTests {

        @Test
        @DisplayName("Deve calcular alíquota 3% para valor < R$ 1.000")
        public void deveCalcularAliquota3ParaValorMenorQue1000() {
            Pedido pedido = criarPedidoBase(900, 50, TipoPessoa.JURIDICA,
                RegimeTributacaoPJ.LUCRO_REAL, Regiao.SUDESTE);

            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);

            assertEquals(0.03 * 90, notaFiscal.getItens().get(0).getValorTributoItem(), 0.01);
        }

        @Test
        @DisplayName("Deve calcular alíquota 9% para valor entre R$ 1.000 e R$ 2.000")
        public void deveCalcularAliquota9ParaValorEntre1000E2000() {
            Pedido pedido = criarPedidoBase(1800, 60, TipoPessoa.JURIDICA,
                RegimeTributacaoPJ.LUCRO_REAL, Regiao.SUL);

            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);

            assertEquals(0.09 * 180, notaFiscal.getItens().get(0).getValorTributoItem(), 0.01);
        }

        @Test
        @DisplayName("Deve calcular alíquota 15% para valor entre R$ 2.000 e R$ 5.000")
        public void deveCalcularAliquota15ParaValorEntre2000E5000() {
            Pedido pedido = criarPedidoBase(4000, 80, TipoPessoa.JURIDICA,
                RegimeTributacaoPJ.LUCRO_REAL, Regiao.NORTE);

            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);

            assertEquals(0.15 * 400, notaFiscal.getItens().get(0).getValorTributoItem(), 0.01);
        }

        @Test
        @DisplayName("Deve calcular alíquota 20% para valor > R$ 5.000")
        public void deveCalcularAliquota20ParaValorMaiorQue5000() {
            Pedido pedido = criarPedidoBase(7000, 100, TipoPessoa.JURIDICA,
                RegimeTributacaoPJ.LUCRO_REAL, Regiao.CENTRO_OESTE);

            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);

            assertEquals(0.20 * 700, notaFiscal.getItens().get(0).getValorTributoItem(), 0.01);
        }
    }

    @Nested
    @DisplayName("Testes para Pessoa Jurídica - Lucro Presumido")
    class PessoaJuridicaLucroPresumidoTests {

        @Test
        @DisplayName("Deve calcular alíquota 3% para valor < R$ 1.000")
        public void deveCalcularAliquota3ParaValorMenorQue1000() {
            Pedido pedido = criarPedidoBase(950, 45, TipoPessoa.JURIDICA,
                RegimeTributacaoPJ.LUCRO_PRESUMIDO, Regiao.SUDESTE);

            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);

            assertEquals(0.03 * 95, notaFiscal.getItens().get(0).getValorTributoItem(), 0.01);
        }

        @Test
        @DisplayName("Deve calcular alíquota 9% para valor entre R$ 1.000 e R$ 2.000")
        public void deveCalcularAliquota9ParaValorEntre1000E2000() {
            Pedido pedido = criarPedidoBase(1600, 55, TipoPessoa.JURIDICA,
                RegimeTributacaoPJ.LUCRO_PRESUMIDO, Regiao.SUL);

            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);

            assertEquals(0.09 * 160, notaFiscal.getItens().get(0).getValorTributoItem(), 0.01);
        }

        @Test
        @DisplayName("Deve calcular alíquota 16% para valor entre R$ 2.000 e R$ 5.000")
        public void deveCalcularAliquota16ParaValorEntre2000E5000() {
            Pedido pedido = criarPedidoBase(4500, 85, TipoPessoa.JURIDICA,
                RegimeTributacaoPJ.LUCRO_PRESUMIDO, Regiao.NORDESTE);

            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);

            assertEquals(0.16 * 450, notaFiscal.getItens().get(0).getValorTributoItem(), 0.01);
        }

        @Test
        @DisplayName("Deve calcular alíquota 20% para valor > R$ 5.000")
        public void deveCalcularAliquota20ParaValorMaiorQue5000() {
            Pedido pedido = criarPedidoBase(6000, 100, TipoPessoa.JURIDICA,
                RegimeTributacaoPJ.LUCRO_PRESUMIDO, Regiao.NORTE);

            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);

            assertNotNull(notaFiscal);
            assertEquals(6000, notaFiscal.getValorTotalItens());
            assertEquals(1, notaFiscal.getItens().size());
            assertEquals(0.20 * 600, notaFiscal.getItens().get(0).getValorTributoItem(), 0.01);
        }
    }

    @Nested
    @DisplayName("Testes de Cálculo de Frete por Região")
    class CalculoFreteTests {

        @Test
        @DisplayName("Deve aplicar 8% de acréscimo para região Norte")
        public void deveAplicar8PorcentoParaRegiaoNorte() {
            Pedido pedido = criarPedidoBase(1000, 100, TipoPessoa.FISICA, null, Regiao.NORTE);

            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);

            assertEquals(108.0, notaFiscal.getValorFrete(), 0.01);
        }

        @Test
        @DisplayName("Deve aplicar 8.5% de acréscimo para região Nordeste")
        public void deveAplicar85PorcentoParaRegiaoNordeste() {
            Pedido pedido = criarPedidoBase(1000, 100, TipoPessoa.FISICA, null, Regiao.NORDESTE);

            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);

            assertEquals(108.5, notaFiscal.getValorFrete(), 0.01);
        }

        @Test
        @DisplayName("Deve aplicar 7% de acréscimo para região Centro-Oeste")
        public void deveAplicar7PorcentoParaRegiaoCentroOeste() {
            Pedido pedido = criarPedidoBase(1000, 100, TipoPessoa.FISICA, null, Regiao.CENTRO_OESTE);

            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);

            assertEquals(107.0, notaFiscal.getValorFrete(), 0.01);
        }

        @Test
        @DisplayName("Deve aplicar 4.8% de acréscimo para região Sudeste")
        public void deveAplicar48PorcentoParaRegiaoSudeste() {
            Pedido pedido = criarPedidoBase(1000, 100, TipoPessoa.FISICA, null, Regiao.SUDESTE);

            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);

            assertEquals(104.8, notaFiscal.getValorFrete(), 0.01);
        }

        @Test
        @DisplayName("Deve aplicar 6% de acréscimo para região Sul")
        public void deveAplicar6PorcentoParaRegiaoSul() {
            Pedido pedido = criarPedidoBase(1000, 100, TipoPessoa.FISICA, null, Regiao.SUL);

            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);

            assertEquals(106.0, notaFiscal.getValorFrete(), 0.01);
        }
    }

    @Nested
    @DisplayName("Testes de Validação de Dados")
    class ValidacaoTests {

        @Test
        @DisplayName("Deve gerar nota fiscal com ID único")
        public void deveGerarNotaFiscalComIdUnico() {
            Pedido pedido1 = criarPedidoBase(1000, 50, TipoPessoa.FISICA, null, Regiao.SUDESTE);
            Pedido pedido2 = criarPedidoBase(1000, 50, TipoPessoa.FISICA, null, Regiao.SUDESTE);

            NotaFiscal nf1 = geradorNotaFiscalService.gerarNotaFiscal(pedido1);
            NotaFiscal nf2 = geradorNotaFiscalService.gerarNotaFiscal(pedido2);

            assertNotEquals(nf1.getIdNotaFiscal(), nf2.getIdNotaFiscal());
        }

        @Test
        @DisplayName("Deve gerar nota fiscal com data atual")
        public void deveGerarNotaFiscalComDataAtual() {
            Pedido pedido = criarPedidoBase(1000, 50, TipoPessoa.FISICA, null, Regiao.SUDESTE);

            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);

            assertNotNull(notaFiscal.getData());
        }

        @Test
        @DisplayName("Deve copiar destinatário para nota fiscal")
        public void deveCopiarDestinatarioParaNotaFiscal() {
            Pedido pedido = criarPedidoBase(1000, 50, TipoPessoa.FISICA, null, Regiao.SUDESTE);
            pedido.getDestinatario().setNome("João Silva");

            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);

            assertNotNull(notaFiscal.getDestinatario());
            assertEquals("João Silva", notaFiscal.getDestinatario().getNome());
        }

        @Test
        @DisplayName("Deve processar pedido com múltiplos itens")
        public void deveProcessarPedidoComMultiplosItens() {
            Pedido pedido = criarPedidoBase(2000, 50, TipoPessoa.FISICA, null, Regiao.SUDESTE);

            Item item2 = new Item();
            item2.setIdItem("ITEM002");
            item2.setDescricao("Produto 2");
            item2.setValorUnitario(100);
            item2.setQuantidade(5);

            pedido.getItens().add(item2);

            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);

            assertEquals(2, notaFiscal.getItens().size());
        }
    }

    private Pedido criarPedidoBase(double valorTotal, double valorFrete, TipoPessoa tipoPessoa,
                                   RegimeTributacaoPJ regime, Regiao regiao) {
        Pedido pedido = new Pedido();
        pedido.setIdPedido(1);
        pedido.setData(LocalDate.now());
        pedido.setValorTotalItens(valorTotal);
        pedido.setValorFrete(valorFrete);

        Destinatario destinatario = new Destinatario();
        destinatario.setNome("Cliente Teste");
        destinatario.setTipoPessoa(tipoPessoa);

        if (regime != null) {
            destinatario.setRegimeTributacao(regime);
        }

        Endereco endereco = new Endereco();
        endereco.setCep("01310-100");
        endereco.setLogradouro("Av Paulista");
        endereco.setNumero("1000");
        endereco.setEstado("SP");
        endereco.setFinalidade(Finalidade.ENTREGA);
        endereco.setRegiao(regiao);

        destinatario.setEnderecos(Collections.singletonList(endereco));
        pedido.setDestinatario(destinatario);

        Item item = new Item();
        item.setIdItem("ITEM001");
        item.setDescricao("Produto Teste");
        item.setValorUnitario(valorTotal / 10);
        item.setQuantidade(10);

        pedido.setItens(Collections.singletonList(item));

        return pedido;
    }

}