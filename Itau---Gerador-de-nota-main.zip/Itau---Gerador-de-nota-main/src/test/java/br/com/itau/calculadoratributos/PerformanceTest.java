package br.com.itau.calculadoratributos;

import br.com.itau.geradornotafiscal.model.*;
import br.com.itau.geradornotafiscal.service.impl.GeradorNotaFiscalServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Testes de Performance")
public class PerformanceTest {

    private GeradorNotaFiscalServiceImpl geradorNotaFiscalService;

    @BeforeEach
    public void setup() {
        geradorNotaFiscalService = new GeradorNotaFiscalServiceImpl();
    }

    @Test
    @DisplayName("Deve processar pedido com 1 item em menos de 2 segundos")
    public void deveProcessarPedido1ItemRapido() {
        Pedido pedido = criarPedidoComNItens(1);

        long inicio = System.currentTimeMillis();
        NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);
        long fim = System.currentTimeMillis();

        long tempoExecucao = fim - inicio;

        assertNotNull(notaFiscal);
        assertTrue(tempoExecucao < 2000,
            String.format("Processamento demorou %dms, deveria ser < 2000ms", tempoExecucao));
        System.out.println("✅ Pedido com 1 item processado em " + tempoExecucao + "ms");
    }

    @Test
    @DisplayName("Deve processar pedido com 5 itens em menos de 2 segundos")
    public void deveProcessarPedido5ItensRapido() {
        Pedido pedido = criarPedidoComNItens(5);

        long inicio = System.currentTimeMillis();
        NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);
        long fim = System.currentTimeMillis();

        long tempoExecucao = fim - inicio;

        assertNotNull(notaFiscal);
        assertEquals(5, notaFiscal.getItens().size());
        assertTrue(tempoExecucao < 2000,
            String.format("Processamento demorou %dms, deveria ser < 2000ms", tempoExecucao));
        System.out.println("✅ Pedido com 5 itens processado em " + tempoExecucao + "ms");
    }

    @Test
    @DisplayName("Deve processar pedido com 10 itens em menos de 2.5 segundos")
    public void deveProcessarPedido10ItensRapido() {
        Pedido pedido = criarPedidoComNItens(10);

        long inicio = System.currentTimeMillis();
        NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);
        long fim = System.currentTimeMillis();

        long tempoExecucao = fim - inicio;

        assertNotNull(notaFiscal);
        assertEquals(10, notaFiscal.getItens().size());
        assertTrue(tempoExecucao < 2500,
            String.format("Processamento demorou %dms, deveria ser < 2500ms", tempoExecucao));
        System.out.println("✅ Pedido com 10 itens processado em " + tempoExecucao + "ms");
    }

    @Test
    @DisplayName("Deve processar pedido com 20 itens em menos de 3 segundos")
    public void deveProcessarPedido20ItensRapido() {
        Pedido pedido = criarPedidoComNItens(20);

        long inicio = System.currentTimeMillis();
        NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);
        long fim = System.currentTimeMillis();

        long tempoExecucao = fim - inicio;

        assertNotNull(notaFiscal);
        assertEquals(20, notaFiscal.getItens().size());
        assertTrue(tempoExecucao < 3000,
            String.format("Processamento demorou %dms, deveria ser < 3000ms", tempoExecucao));
        System.out.println("✅ Pedido com 20 itens processado em " + tempoExecucao + "ms");
    }

    @Test
    @DisplayName("Deve processar 10 pedidos sequenciais em tempo aceitável")
    public void deveProcessar10PedidosSequenciais() {
        long tempoTotal = 0;

        for (int i = 0; i < 10; i++) {
            Pedido pedido = criarPedidoComNItens(3);

            long inicio = System.currentTimeMillis();
            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);
            long fim = System.currentTimeMillis();

            assertNotNull(notaFiscal);
            tempoTotal += (fim - inicio);
        }

        long tempoMedio = tempoTotal / 10;

        assertTrue(tempoMedio < 2000,
            String.format("Tempo médio foi %dms, deveria ser < 2000ms", tempoMedio));
        System.out.println("✅ 10 pedidos processados - Tempo médio: " + tempoMedio + "ms - Total: " + tempoTotal + "ms");
    }

    @Test
    @DisplayName("Deve manter performance consistente em múltiplas execuções")
    public void deveManterPerformanceConsistente() {
        List<Long> tempos = new ArrayList<>();

        for (int i = 0; i < 5; i++) {
            Pedido pedido = criarPedidoComNItens(5);

            long inicio = System.currentTimeMillis();
            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);
            long fim = System.currentTimeMillis();

            assertNotNull(notaFiscal);
            tempos.add(fim - inicio);
        }

        long tempoMedio = tempos.stream().mapToLong(Long::longValue).sum() / tempos.size();
        long tempoMaximo = tempos.stream().mapToLong(Long::longValue).max().orElse(0);
        long tempoMinimo = tempos.stream().mapToLong(Long::longValue).min().orElse(0);

        // A variação não deve ser muito grande (máximo 2x o mínimo)
        assertTrue(tempoMaximo < tempoMinimo * 2,
            String.format("Variação muito grande: min=%dms, max=%dms", tempoMinimo, tempoMaximo));

        System.out.println(String.format("✅ Performance consistente - Min: %dms, Médio: %dms, Max: %dms",
            tempoMinimo, tempoMedio, tempoMaximo));
    }

    @Test
    @DisplayName("Deve processar diferentes tipos de pessoa em tempo similar")
    public void deveProcessarDiferentesTiposPessoaEmTempoSimilar() {
        // Pessoa Física
        Pedido pedidoPF = criarPedidoBase(1500, 50, TipoPessoa.FISICA, null, Regiao.SUDESTE);
        long inicioPF = System.currentTimeMillis();
        NotaFiscal nfPF = geradorNotaFiscalService.gerarNotaFiscal(pedidoPF);
        long tempoPF = System.currentTimeMillis() - inicioPF;

        // Pessoa Jurídica
        Pedido pedidoPJ = criarPedidoBase(1500, 50, TipoPessoa.JURIDICA,
            RegimeTributacaoPJ.SIMPLES_NACIONAL, Regiao.SUDESTE);
        long inicioPJ = System.currentTimeMillis();
        NotaFiscal nfPJ = geradorNotaFiscalService.gerarNotaFiscal(pedidoPJ);
        long tempoPJ = System.currentTimeMillis() - inicioPJ;

        assertNotNull(nfPF);
        assertNotNull(nfPJ);

        // Diferença não deve ser maior que 500ms
        long diferenca = Math.abs(tempoPF - tempoPJ);
        assertTrue(diferenca < 500,
            String.format("Diferença de %dms muito grande (PF: %dms, PJ: %dms)", diferenca, tempoPF, tempoPJ));

        System.out.println(String.format("✅ PF: %dms, PJ: %dms, Diferença: %dms", tempoPF, tempoPJ, diferenca));
    }

    @Test
    @DisplayName("Deve processar todas as regiões em tempo similar")
    public void deveProcessarTodasRegioesEmTempoSimilar() {
        List<Long> temposPorRegiao = new ArrayList<>();

        for (Regiao regiao : Regiao.values()) {
            Pedido pedido = criarPedidoBase(1500, 50, TipoPessoa.FISICA, null, regiao);

            long inicio = System.currentTimeMillis();
            NotaFiscal notaFiscal = geradorNotaFiscalService.gerarNotaFiscal(pedido);
            long tempo = System.currentTimeMillis() - inicio;

            assertNotNull(notaFiscal);
            temposPorRegiao.add(tempo);
        }

        long tempoMedio = temposPorRegiao.stream().mapToLong(Long::longValue).sum() / temposPorRegiao.size();
        long tempoMaximo = temposPorRegiao.stream().mapToLong(Long::longValue).max().orElse(0);
        long tempoMinimo = temposPorRegiao.stream().mapToLong(Long::longValue).min().orElse(0);

        // Variação não deve ser muito grande
        assertTrue(tempoMaximo < tempoMinimo * 1.5,
            String.format("Variação entre regiões muito grande: min=%dms, max=%dms", tempoMinimo, tempoMaximo));

        System.out.println(String.format("✅ Todas regiões - Min: %dms, Médio: %dms, Max: %dms",
            tempoMinimo, tempoMedio, tempoMaximo));
    }

    @Test
    @DisplayName("Performance - Análise completa com relatório")
    public void analisePerformanceCompleta() {
        System.out.println("\n========================================");
        System.out.println("📊 ANÁLISE DE PERFORMANCE COMPLETA");
        System.out.println("========================================\n");

        // Teste com diferentes quantidades de itens
        int[] quantidades = {1, 5, 10, 15, 20};

        for (int qtd : quantidades) {
            List<Long> tempos = new ArrayList<>();

            for (int i = 0; i < 3; i++) {
                Pedido pedido = criarPedidoComNItens(qtd);
                long inicio = System.currentTimeMillis();
                geradorNotaFiscalService.gerarNotaFiscal(pedido);
                tempos.add(System.currentTimeMillis() - inicio);
            }

            long tempoMedio = tempos.stream().mapToLong(Long::longValue).sum() / tempos.size();
            System.out.println(String.format("📦 %2d itens: %4dms (média de 3 execuções)", qtd, tempoMedio));
        }

        System.out.println("\n========================================");
        System.out.println("✅ ANÁLISE CONCLUÍDA");
        System.out.println("========================================\n");

        assertTrue(true); // Sempre passa, apenas para relatório
    }

    private Pedido criarPedidoComNItens(int quantidade) {
        Pedido pedido = criarPedidoBase(quantidade * 100.0, 50, TipoPessoa.FISICA, null, Regiao.SUDESTE);

        List<Item> itens = new ArrayList<>();
        for (int i = 1; i <= quantidade; i++) {
            Item item = new Item();
            item.setIdItem("ITEM" + String.format("%03d", i));
            item.setDescricao("Produto " + i);
            item.setValorUnitario(100);
            item.setQuantidade(1);
            itens.add(item);
        }

        pedido.setItens(itens);
        return pedido;
    }

    private Pedido criarPedidoBase(double valorTotal, double valorFrete, TipoPessoa tipoPessoa,
                                   RegimeTributacaoPJ regime, Regiao regiao) {
        Pedido pedido = new Pedido();
        pedido.setIdPedido(1);
        pedido.setData(LocalDate.now());
        pedido.setValorTotalItens(valorTotal);
        pedido.setValorFrete(valorFrete);

        Destinatario destinatario = new Destinatario();
        destinatario.setNome("Cliente Teste");
        destinatario.setTipoPessoa(tipoPessoa);

        if (regime != null) {
            destinatario.setRegimeTributacao(regime);
        }

        Endereco endereco = new Endereco();
        endereco.setCep("01310-100");
        endereco.setLogradouro("Av Paulista");
        endereco.setNumero("1000");
        endereco.setEstado("SP");
        endereco.setFinalidade(Finalidade.ENTREGA);
        endereco.setRegiao(regiao);

        destinatario.setEnderecos(Collections.singletonList(endereco));
        pedido.setDestinatario(destinatario);

        Item item = new Item();
        item.setIdItem("ITEM001");
        item.setDescricao("Produto Teste");
        item.setValorUnitario(valorTotal / 10);
        item.setQuantidade(10);

        pedido.setItens(Collections.singletonList(item));

        return pedido;
    }
}
