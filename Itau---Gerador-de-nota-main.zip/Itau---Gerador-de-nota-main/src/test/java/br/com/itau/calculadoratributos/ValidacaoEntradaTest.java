package br.com.itau.calculadoratributos;

import br.com.itau.geradornotafiscal.model.*;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Nested;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("Validações de Entrada - Testes")
public class ValidacaoEntradaTest {

    @Nested
    @DisplayName("Validações de Pedido")
    class ValidacaoPedidoTests {

        @Test
        @DisplayName("Deve validar que pedido não pode ter valor total negativo")
        public void deveValidarValorTotalNaoNegativo() {
            Pedido pedido = criarPedidoBase(-100, 50, TipoPessoa.FISICA, null, Regiao.SUDESTE);

            assertNotNull(pedido);
            assertTrue(pedido.getValorTotalItens() < 0, "Valor total do pedido é negativo");
        }

        @Test
        @DisplayName("Deve validar que pedido não pode ter frete negativo")
        public void deveValidarFreteNaoNegativo() {
            Pedido pedido = criarPedidoBase(1000, -50, TipoPessoa.FISICA, null, Regiao.SUDESTE);

            assertNotNull(pedido);
            assertTrue(pedido.getValorFrete() < 0, "Valor do frete é negativo");
        }

        @Test
        @DisplayName("Deve validar que pedido pode ter valor total zero")
        public void deveAceitarValorTotalZero() {
            Pedido pedido = criarPedidoBase(0, 50, TipoPessoa.FISICA, null, Regiao.SUDESTE);

            assertNotNull(pedido);
            assertEquals(0, pedido.getValorTotalItens());
        }

        @Test
        @DisplayName("Deve validar que pedido pode ter frete zero")
        public void deveAceitarFreteZero() {
            Pedido pedido = criarPedidoBase(1000, 0, TipoPessoa.FISICA, null, Regiao.SUDESTE);

            assertNotNull(pedido);
            assertEquals(0, pedido.getValorFrete());
        }

        @Test
        @DisplayName("Deve validar que pedido possui destinatário")
        public void deveValidarDestinatarioObrigatorio() {
            Pedido pedido = new Pedido();
            pedido.setIdPedido(1);
            pedido.setData(LocalDate.now());
            pedido.setValorTotalItens(1000);
            pedido.setValorFrete(50);

            assertNull(pedido.getDestinatario(), "Destinatário não foi definido");
        }

        @Test
        @DisplayName("Deve validar que pedido possui itens")
        public void deveValidarItensObrigatorios() {
            Pedido pedido = new Pedido();
            pedido.setIdPedido(1);
            pedido.setData(LocalDate.now());
            pedido.setValorTotalItens(1000);
            pedido.setValorFrete(50);
            pedido.setItens(new ArrayList<>());

            assertTrue(pedido.getItens().isEmpty(), "Lista de itens está vazia");
        }
    }

    @Nested
    @DisplayName("Validações de Destinatário")
    class ValidacaoDestinatarioTests {

        @Test
        @DisplayName("Deve validar que destinatário PJ deve ter regime tributário")
        public void deveValidarRegimeTributarioParaPJ() {
            Destinatario destinatario = new Destinatario();
            destinatario.setNome("Empresa Teste");
            destinatario.setTipoPessoa(TipoPessoa.JURIDICA);

            assertNull(destinatario.getRegimeTributacao(),
                "Pessoa jurídica sem regime tributário definido");
        }

        @Test
        @DisplayName("Deve validar que destinatário possui endereços")
        public void deveValidarEnderecosObrigatorios() {
            Destinatario destinatario = new Destinatario();
            destinatario.setNome("Cliente Teste");
            destinatario.setTipoPessoa(TipoPessoa.FISICA);

            assertNull(destinatario.getEnderecos(), "Endereços não definidos");
        }

        @Test
        @DisplayName("Deve validar que destinatário possui nome")
        public void deveValidarNomeObrigatorio() {
            Destinatario destinatario = new Destinatario();
            destinatario.setTipoPessoa(TipoPessoa.FISICA);

            assertNull(destinatario.getNome(), "Nome não definido");
        }

        @Test
        @DisplayName("Deve validar que destinatário possui tipo de pessoa")
        public void deveValidarTipoPessoaObrigatorio() {
            Destinatario destinatario = new Destinatario();
            destinatario.setNome("Cliente Teste");

            assertNull(destinatario.getTipoPessoa(), "Tipo de pessoa não definido");
        }
    }

    @Nested
    @DisplayName("Validações de Item")
    class ValidacaoItemTests {

        @Test
        @DisplayName("Deve validar que item não pode ter valor unitário negativo")
        public void deveValidarValorUnitarioNaoNegativo() {
            Item item = new Item();
            item.setIdItem("ITEM001");
            item.setDescricao("Produto Teste");
            item.setValorUnitario(-50);
            item.setQuantidade(10);

            assertTrue(item.getValorUnitario() < 0, "Valor unitário é negativo");
        }

        @Test
        @DisplayName("Deve validar que item não pode ter quantidade negativa")
        public void deveValidarQuantidadeNaoNegativa() {
            Item item = new Item();
            item.setIdItem("ITEM001");
            item.setDescricao("Produto Teste");
            item.setValorUnitario(50);
            item.setQuantidade(-10);

            assertTrue(item.getQuantidade() < 0, "Quantidade é negativa");
        }

        @Test
        @DisplayName("Deve validar que item não pode ter quantidade zero")
        public void deveValidarQuantidadeNaoZero() {
            Item item = new Item();
            item.setIdItem("ITEM001");
            item.setDescricao("Produto Teste");
            item.setValorUnitario(50);
            item.setQuantidade(0);

            assertEquals(0, item.getQuantidade(), "Quantidade é zero");
        }

        @Test
        @DisplayName("Deve validar que item possui ID")
        public void deveValidarIdObrigatorio() {
            Item item = new Item();
            item.setDescricao("Produto Teste");
            item.setValorUnitario(50);
            item.setQuantidade(10);

            assertNull(item.getIdItem(), "ID do item não definido");
        }

        @Test
        @DisplayName("Deve validar que item possui descrição")
        public void deveValidarDescricaoObrigatoria() {
            Item item = new Item();
            item.setIdItem("ITEM001");
            item.setValorUnitario(50);
            item.setQuantidade(10);

            assertNull(item.getDescricao(), "Descrição não definida");
        }
    }

    @Nested
    @DisplayName("Validações de Endereço")
    class ValidacaoEnderecoTests {

        @Test
        @DisplayName("Deve validar que endereço possui CEP")
        public void deveValidarCepObrigatorio() {
            Endereco endereco = new Endereco();
            endereco.setLogradouro("Av Paulista");
            endereco.setNumero("1000");
            endereco.setEstado("SP");
            endereco.setFinalidade(Finalidade.ENTREGA);
            endereco.setRegiao(Regiao.SUDESTE);

            assertNull(endereco.getCep(), "CEP não definido");
        }

        @Test
        @DisplayName("Deve validar que endereço possui logradouro")
        public void deveValidarLogradouroObrigatorio() {
            Endereco endereco = new Endereco();
            endereco.setCep("01310-100");
            endereco.setNumero("1000");
            endereco.setEstado("SP");
            endereco.setFinalidade(Finalidade.ENTREGA);
            endereco.setRegiao(Regiao.SUDESTE);

            assertNull(endereco.getLogradouro(), "Logradouro não definido");
        }

        @Test
        @DisplayName("Deve validar que endereço possui região")
        public void deveValidarRegiaoObrigatoria() {
            Endereco endereco = new Endereco();
            endereco.setCep("01310-100");
            endereco.setLogradouro("Av Paulista");
            endereco.setNumero("1000");
            endereco.setEstado("SP");
            endereco.setFinalidade(Finalidade.ENTREGA);

            assertNull(endereco.getRegiao(), "Região não definida");
        }

        @Test
        @DisplayName("Deve validar que endereço possui finalidade")
        public void deveValidarFinalidadeObrigatoria() {
            Endereco endereco = new Endereco();
            endereco.setCep("01310-100");
            endereco.setLogradouro("Av Paulista");
            endereco.setNumero("1000");
            endereco.setEstado("SP");
            endereco.setRegiao(Regiao.SUDESTE);

            assertNull(endereco.getFinalidade(), "Finalidade não definida");
        }
    }

    @Nested
    @DisplayName("Testes de Casos Limite")
    class CasosLimiteTests {

        @Test
        @DisplayName("Deve processar pedido com valor exatamente R$ 500")
        public void deveProcessarPedidoComValorExato500() {
            Pedido pedido = criarPedidoBase(500, 50, TipoPessoa.FISICA, null, Regiao.SUDESTE);

            assertNotNull(pedido);
            assertEquals(500, pedido.getValorTotalItens());
        }

        @Test
        @DisplayName("Deve processar pedido com valor exatamente R$ 2.000")
        public void deveProcessarPedidoComValorExato2000() {
            Pedido pedido = criarPedidoBase(2000, 50, TipoPessoa.FISICA, null, Regiao.SUDESTE);

            assertNotNull(pedido);
            assertEquals(2000, pedido.getValorTotalItens());
        }

        @Test
        @DisplayName("Deve processar pedido com valor exatamente R$ 3.500")
        public void deveProcessarPedidoComValorExato3500() {
            Pedido pedido = criarPedidoBase(3500, 50, TipoPessoa.FISICA, null, Regiao.SUDESTE);

            assertNotNull(pedido);
            assertEquals(3500, pedido.getValorTotalItens());
        }

        @Test
        @DisplayName("Deve processar pedido PJ com valor exatamente R$ 1.000")
        public void deveProcessarPedidoPJComValorExato1000() {
            Pedido pedido = criarPedidoBase(1000, 50, TipoPessoa.JURIDICA,
                RegimeTributacaoPJ.SIMPLES_NACIONAL, Regiao.SUDESTE);

            assertNotNull(pedido);
            assertEquals(1000, pedido.getValorTotalItens());
        }

        @Test
        @DisplayName("Deve processar pedido PJ com valor exatamente R$ 5.000")
        public void deveProcessarPedidoPJComValorExato5000() {
            Pedido pedido = criarPedidoBase(5000, 50, TipoPessoa.JURIDICA,
                RegimeTributacaoPJ.LUCRO_REAL, Regiao.SUDESTE);

            assertNotNull(pedido);
            assertEquals(5000, pedido.getValorTotalItens());
        }

        @Test
        @DisplayName("Deve processar pedido com valor muito alto")
        public void deveProcessarPedidoComValorMuitoAlto() {
            Pedido pedido = criarPedidoBase(999999.99, 1000, TipoPessoa.JURIDICA,
                RegimeTributacaoPJ.LUCRO_PRESUMIDO, Regiao.NORTE);

            assertNotNull(pedido);
            assertEquals(999999.99, pedido.getValorTotalItens(), 0.01);
        }
    }

    @Nested
    @DisplayName("Testes de Integridade de Dados")
    class IntegridadeDadosTests {

        @Test
        @DisplayName("Deve manter consistência entre tipo pessoa e regime tributário")
        public void deveManterConsistenciaTipoPessoaRegime() {
            Destinatario destinatario = new Destinatario();
            destinatario.setNome("Empresa Teste");
            destinatario.setTipoPessoa(TipoPessoa.JURIDICA);
            destinatario.setRegimeTributacao(RegimeTributacaoPJ.LUCRO_REAL);

            assertEquals(TipoPessoa.JURIDICA, destinatario.getTipoPessoa());
            assertNotNull(destinatario.getRegimeTributacao());
        }

        @Test
        @DisplayName("Deve validar que PF não deve ter regime tributário")
        public void deveValidarPFSemRegimeTributario() {
            Destinatario destinatario = new Destinatario();
            destinatario.setNome("João Silva");
            destinatario.setTipoPessoa(TipoPessoa.FISICA);

            assertEquals(TipoPessoa.FISICA, destinatario.getTipoPessoa());
            assertNull(destinatario.getRegimeTributacao());
        }

        @Test
        @DisplayName("Deve validar que todas as regiões estão mapeadas")
        public void deveValidarTodasRegioesMapeadas() {
            Regiao[] regioes = Regiao.values();

            assertEquals(5, regioes.length, "Devem existir 5 regiões");
            assertArrayEquals(
                new Regiao[]{Regiao.NORTE, Regiao.NORDESTE, Regiao.CENTRO_OESTE,
                            Regiao.SUDESTE, Regiao.SUL},
                regioes
            );
        }

        @Test
        @DisplayName("Deve validar que todos os regimes tributários estão mapeados")
        public void deveValidarTodosRegimesMapeados() {
            RegimeTributacaoPJ[] regimes = RegimeTributacaoPJ.values();

            assertEquals(3, regimes.length, "Devem existir 3 regimes tributários");
            assertArrayEquals(
                new RegimeTributacaoPJ[]{
                    RegimeTributacaoPJ.SIMPLES_NACIONAL,
                    RegimeTributacaoPJ.LUCRO_REAL,
                    RegimeTributacaoPJ.LUCRO_PRESUMIDO
                },
                regimes
            );
        }
    }

    private Pedido criarPedidoBase(double valorTotal, double valorFrete, TipoPessoa tipoPessoa,
                                   RegimeTributacaoPJ regime, Regiao regiao) {
        Pedido pedido = new Pedido();
        pedido.setIdPedido(1);
        pedido.setData(LocalDate.now());
        pedido.setValorTotalItens(valorTotal);
        pedido.setValorFrete(valorFrete);

        Destinatario destinatario = new Destinatario();
        destinatario.setNome("Cliente Teste");
        destinatario.setTipoPessoa(tipoPessoa);

        if (regime != null) {
            destinatario.setRegimeTributacao(regime);
        }

        Endereco endereco = new Endereco();
        endereco.setCep("01310-100");
        endereco.setLogradouro("Av Paulista");
        endereco.setNumero("1000");
        endereco.setEstado("SP");
        endereco.setFinalidade(Finalidade.ENTREGA);
        endereco.setRegiao(regiao);

        destinatario.setEnderecos(Collections.singletonList(endereco));
        pedido.setDestinatario(destinatario);

        Item item = new Item();
        item.setIdItem("ITEM001");
        item.setDescricao("Produto Teste");
        item.setValorUnitario(valorTotal / 10);
        item.setQuantidade(10);

        pedido.setItens(Collections.singletonList(item));

        return pedido;
    }
}
