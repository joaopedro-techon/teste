package br.com.itau.calculadoratributos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculadoratributosApplicationTests {

	@Test
	void contextLoads() {
	}

}
